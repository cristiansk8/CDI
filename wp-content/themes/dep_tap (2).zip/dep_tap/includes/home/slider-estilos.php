
<section id="slider-estilos">
  <div class="slider-estilos">

    <div class="row slide-general" id="familia" style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/fondo6.jpg); background-position:center;">
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-19.png" alt="" width="80%" height="auto">
      </div>
      <div class="col-md-6 text-general-s text-s1" >
        <h2>ESPACIOS<br> QUE <span>HABLAN <br>SOBRE TI</span> </h2>
      </div>
    </div>

    <div class="slide-general" id="influencer"style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/fondo4.jpg);background-position:left;">
      <div class="col-md-6 text-general-s text-s2">
        <h2>PERSONALIZA<br> SEGÚN TU<br><span>ESTILO DE VIDA</span> </h2>
      </div>
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-17.png" alt="" width="80%" height="auto">
      </div>
    </div>

    <div class="slide-general" id="deportistas"style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/fondo2.jpg); background-position:center;">
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-13.png" alt="" width="80%" height="auto">
      </div>
      <div class="col-md-6 text-general-s text-s3">
        <h2>PARA LOS QUE<br> SOLO QUIEREN <br><span>RODAR</span> </h2>
      </div>
    </div>

    <div class="slide-general" id="mascotas"style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/fondo7.jpg); background-position:left;">
      <div class="col-md-6 text-general-s text-s4">
        <h2>PARA LOS QUE<br> COMPARTEN TODO <br><span>CON SUS PELUDOS</span> </h2>
      </div>
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-15.png" alt="" width="80%" height="auto">
      </div>
    </div>

    <div class="slide-general"id="home-office" style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-13ago2019-cristian-03.jpg); background-position:center;">
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-14.png" alt="" width="80%" height="auto">
      </div>
      <div class="col-md-6 text-general-s text-s5">
        <h2>PARA LOS<br>QUE<span> SU HOGAR ES <br>SU OFICINA</span> </h2>
      </div>
    </div>

    <div class="slide-general" id="todos"style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/fondo5.jpg); background-position:center;">
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-18.png" alt="" width="80%" height="auto">
      </div>
      <div class="col-md-6 text-general-s text-s6">
        <h2>LOS QUE<br>TRABAJAN EN <span>GRUPO</span> </h2>
      </div>
    </div>

    <div class="slide-general" id="musico"style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/fondo3.jpg); background-position:center;">
      <div class="col-md-6 text-general-s text-s7">
        <h2>ESPACIOS <br><span>CREADOS POR TI <br>Y PARA TI</span> </h2>
      </div>
      <div class="col-md-6 plano">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-15agosto-16.png" alt="" width="80%" height="auto">
      </div>
    </div>

  </div>

</section>
