<footer class="container site-footer text-center">
	<p>Copyright © Todos Los Derechos Reservados.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
