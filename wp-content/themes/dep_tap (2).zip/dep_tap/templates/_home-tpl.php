<?php

/*
  Template Name: Home Template
*/

	get_template_part('includes/header');

		get_template_part('includes/home/slider');

		get_template_part('includes/home/productos');

		get_template_part('includes/home/formulario');

		get_template_part('includes/home/recomendaciones');

		get_template_part('includes/home/encuentranos');

	get_template_part('includes/footer');
